"""
Construction du data set d'entrainement
"""

import json 
import os
from utils import RAW_DATA_PATH, PROCESSED_DATA_PATH


def load_data(data_path, train_size, val_size):
    """
    divise data en train, val et test
    """

    with open(data_path, 'r', encoding='utf-8') as f:
        data = json.load(f)

    data = data['data']
    train = data[:int(train_size*len(data))]
    val = data[int(train_size*len(data)):int((train_size+val_size)*len(data))]
    test = data[int((train_size+val_size)*len(data)):]
    
    return train, val, test

def save_data(train, val, test, path):
    """
    save les datasets
    """
    # choix de path
    train_path = os.path.join(path, 'train.json')
    val_path = os.path.join(path, 'val.json')
    test_path = os.path.join(path, 'test.json')

    # sauvegarde
    with open(train_path, 'w', encoding='utf-8') as f:
        json.dump(train, f, indent=4, ensure_ascii=False)
        print('Train set saved to {}'.format(train_path))

    with open(val_path, 'w', encoding='utf-8') as f:
        json.dump(val, f, indent=4, ensure_ascii=False)
        print('Validation set saved to {}'.format(val_path))

    with open(test_path, 'w', encoding='utf-8') as f:
        json.dump(test, f, indent=4, ensure_ascii=False)
        print('Test set saved to {}'.format(test_path))



def main(input_file):
    """ Execute des scripts de traitement de données pour transformer les données brutes de (../raw) en
        données nettoyées prêtes à être analysées ( ../processed)
    """

    input_filepath = os.path.join(RAW_DATA_PATH, input_file)
    train, val, test = load_data(input_filepath, 0.2, 0.05)

    save_data(train, val, test, PROCESSED_DATA_PATH)

if __name__ == '__main__':

    main("donnees_FQuAD.json")

